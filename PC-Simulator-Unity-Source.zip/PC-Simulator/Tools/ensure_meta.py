"""Stable GUIDs for all authored Unity assets, independent of import order."""
from pathlib import Path
import uuid
root=Path(__file__).resolve().parents[1]
for p in sorted((root/'Assets').rglob('*')):
    if p.suffix=='.meta' or Path(str(p)+'.meta').exists(): continue
    guid=uuid.uuid5(uuid.NAMESPACE_URL,'pcsim/'+p.relative_to(root).as_posix()).hex
    importer='folderAsset: yes\nDefaultImporter' if p.is_dir() else 'MonoImporter' if p.suffix=='.cs' else 'AssemblyDefinitionImporter' if p.suffix=='.asmdef' else 'NativeFormatImporter' if p.suffix=='.mat' else 'TextScriptImporter'
    Path(str(p)+'.meta').write_text('fileFormatVersion: 2\nguid: '+guid+'\n'+importer+':\n  externalObjects: {}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n')
print('Unity metadata ready')
