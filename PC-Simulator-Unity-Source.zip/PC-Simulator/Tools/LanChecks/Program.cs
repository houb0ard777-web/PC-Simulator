using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using PCSim;
using UnityEngine;
static class Program
{
    static readonly MethodInfo update=typeof(LanSession).GetMethod("Update",BindingFlags.Instance|BindingFlags.NonPublic);
    static int checks;
    static void Check(bool value,string msg){if(!value)throw new Exception(msg);checks++;}
    static void Pump(LanSession[] sessions,int milliseconds)
    {for(int n=0;n<milliseconds/10;n++){foreach(var s in sessions)update.Invoke(s,null);Thread.Sleep(10);}}
    static void Main()
    {
        var host=new LanSession();var a=new LanSession();var b=new LanSession();var c=new LanSession();var overflow=new LanSession();
        var sessions=new[]{host,a,b,c,overflow};int aid=0,bid=0,cid=0;var hostSeen=new HashSet<int>();var aSeen=new HashSet<int>();var bSeen=new HashSet<int>();var left=new HashSet<int>();
        a.LocalAssigned+=id=>aid=id;b.LocalAssigned+=id=>bid=id;c.LocalAssigned+=id=>cid=id;
        host.PeerUpdated+=(id,pos,yaw)=>hostSeen.Add(id);
        a.PeerUpdated+=(id,pos,yaw)=>{if(id==0)Check(Math.Abs(pos.x-5)<.01,"host pose value");aSeen.Add(id);};
        b.PeerUpdated+=(id,pos,yaw)=>bSeen.Add(id);host.PeerLeft+=id=>left.Add(id);
        host.LocalPosition=new Vector3(5,0,0);a.LocalPosition=new Vector3(6,0,0);b.LocalPosition=new Vector3(7,0,0);
        try
        {
            host.Host();a.Join("127.0.0.1");Pump(sessions,500);b.Join("127.0.0.1");Pump(sessions,500);c.Join("127.0.0.1");Pump(sessions,500);
            Check(aid==1&&bid==2&&cid==3,"assign unique guest slots");
            Check(hostSeen.SetEquals(new[]{1,2,3}),"host receives all guests");
            Check(aSeen.Contains(0)&&aSeen.Contains(2)&&aSeen.Contains(3),"guest sees host and other guests");
            Check(bSeen.Contains(0)&&bSeen.Contains(1)&&bSeen.Contains(3),"host relays guest poses");
            overflow.Join("127.0.0.1");Pump(sessions,300);Check(overflow.Status.Contains("потеряно"),"fifth player rejected");
            b.Stop();Pump(sessions,300);Check(left.Contains(2),"disconnect propagated");
            // Malformed and oversized packets are tested against the actual TCP listener.
            using(var raw=new TcpClient("127.0.0.1",LanSession.Port))
            {
                var stream=raw.GetStream();var text=Encoding.UTF8.GetBytes("not-json\n"+new string('x',3000)+"\n");stream.Write(text,0,text.Length);
                Pump(sessions,300);Check(host.Status.Contains("создана"),"bad packets do not stop host");
            }
            host.Stop();Pump(sessions,300);Check(a.Status.Contains("потеряно")&&c.Status.Contains("потеряно"),"host shutdown reaches guests");
        }
        finally{foreach(var s in sessions)s.Stop();}
        Console.WriteLine("PASS: "+checks+" LAN loopback assertions using real TCP sockets and Unity test adapters. Android/Wi-Fi not tested.");
    }
}
