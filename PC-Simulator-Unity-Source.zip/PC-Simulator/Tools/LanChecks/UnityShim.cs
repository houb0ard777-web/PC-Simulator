// Transport-only test adapters; these do not substitute for Unity or Android testing.
using System;
using System.Text.Json;
namespace UnityEngine
{
    public class MonoBehaviour { }
    public struct Vector3 { public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;} }
    public static class Time {public static float unscaledDeltaTime=.025f;}
    public static class Mathf {public static float Abs(float n){return Math.Abs(n);} }
    public static class JsonUtility
    {
        static JsonSerializerOptions options=new JsonSerializerOptions{IncludeFields=true};
        public static string ToJson(object o){return JsonSerializer.Serialize(o,o.GetType(),options);}
        public static T FromJson<T>(string s){return JsonSerializer.Deserialize<T>(s,options);}
    }
}
