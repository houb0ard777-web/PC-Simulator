using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using PCSim;
static class Program
{
    static int checks;
    static Product[] products;
    static void Check(bool condition,string message) { if(!condition) throw new Exception(message);checks++; }
    static GameModel Fresh(long money=30000) {return new GameModel(products,new Progress{rubles=money});}
    static OwnedItem Ready(GameModel m,string id)
    { Check(m.Buy(id,100),"buy "+id);m.Deliver(110);var i=m.State.inventory.Last();Check(m.Unbox(i.uid),"unbox");return i; }
    static void Install(GameModel m,string id) {Check(m.Install(Ready(m,id).uid),"install "+id);}
    static GameModel Built(string gpu="gtx-460")
    {
        var m=Fresh(2000000);
        foreach(var id in new[]{"case-basic","board-basic","cpu-basic","ram-DDR3-4","cooler-basic","psu-1600",gpu}) Install(m,id);
        return m;
    }
    static void Main(string[] args)
    {
        var options=new JsonSerializerOptions{IncludeFields=true};
        products=JsonSerializer.Deserialize<Catalog>(File.ReadAllText(args[0]),options).items;
        Check(products.Count(p=>p.kind=="gpu")==113,"113 GPUs");
        Check(products.Select(p=>p.id).Distinct().Count()==products.Length,"unique IDs");
        var fresh=Fresh();Check(fresh.State.rubles==30000&&fresh.State.inventory.Count==0&&fresh.State.microCrypto==0,"starter money, no free parts");
        Check(!fresh.ToggleMining(),"incomplete PC cannot mine");
        Check(!fresh.Buy("rtx-blackview-5090",100)&&fresh.State.rubles==30000,"no overdraft");
        Check(fresh.Buy("gtx-460",100),"affordable purchase");
        var ordered=fresh.State.inventory.Single();Check(ordered.status=="ordered","ordered status");
        Check(!fresh.Unbox(ordered.uid)&&!fresh.Install(ordered.uid),"cannot use undelivered part");
        fresh.Deliver(109);Check(ordered.status=="ordered","delivery deadline");
        fresh.Deliver(110);Check(ordered.status=="boxed","delivery complete");
        Check(fresh.Unbox(ordered.uid)&&fresh.Install(ordered.uid),"unbox and install");
        Check(!fresh.Sell(ordered.uid),"cannot sell installed part");
        fresh.Remove("gpu");var before=fresh.State.rubles;Check(fresh.Sell(ordered.uid)&&fresh.State.rubles-before==975,"resale 65 percent");
        var m=Fresh(1000000);Install(m,"board-basic");
        Check(!m.Install(Ready(m,"cpu-mid").uid),"wrong socket rejected");
        Check(!m.Install(Ready(m,"ram-DDR4-4").uid),"wrong DDR rejected");
        Install(m,"cpu-basic");Install(m,"ram-DDR3-4");
        Check(!m.Install(Ready(m,"board-mid").uid),"board replacement compatibility");
        var starter=Fresh();foreach(var id in new[]{"case-basic","board-basic","cpu-basic","ram-DDR3-4","cooler-basic","psu-500","gtx-460"}) Install(starter,id);
        Check(starter.BootIssue()==""&&starter.State.rubles>0,"full PC within 30000 rubles");
        var mine=Built("rtx-3090");Check(mine.Rate==70000,"3090 exact rate");
        Check(mine.ToggleMining(),"start mining");for(int t=0;t<600;t++) mine.Tick(.1);
        Check(Math.Abs(mine.State.microCrypto-4200000)<=1,"3090 60s rate preserves fractional crypto");
        var cash=mine.State.rubles;mine.Exchange();Check(mine.State.rubles-cash>=419999&&mine.State.microCrypto<10,"exchange accounting");
        mine.ToggleMining();var crypto=mine.State.microCrypto;mine.Tick(1);Check(mine.State.microCrypto==crypto,"stopped miner earns nothing");
        Install(mine,"rtx-blackview-5090");Check(mine.Rate==100000&&mine.Products["rtx-blackview-5090"].price==350000,"BlackView price/rate");
        Check(!mine.State.mining,"changing parts stops mining");
        mine.ToggleMining();mine.Remove("cpu");mine.Tick(.5);Check(!mine.State.mining,"removal stops mining");
        var weak=Built("rtx-blackview-5090");Install(weak,"psu-500");Check(weak.BootIssue().Contains("питания"),"PSU capacity");
        var hot=Fresh(2000000);foreach(var id in new[]{"case-basic","board-pro","cpu-pro","ram-DDR5-128","cooler-basic","psu-1600","gtx-460"}) Install(hot,id);
        Check(hot.BootIssue().Contains("Кулер"),"cooling capacity");
        Install(hot,"cooler-pro");Check(hot.BootIssue()=="","high end build");
        var all=Built();all.State.rubles=10000000;foreach(var p in products.Where(p=>p.kind=="gpu")) Install(all,p.id);
        Check(all.Part("gpu").id==products.Last(p=>p.kind=="gpu").id,"all 113 SKUs installable");
        var json=JsonSerializer.Serialize(all.State,options);var restored=new GameModel(products,JsonSerializer.Deserialize<Progress>(json,options));
        Check(restored.State.rubles==all.State.rubles&&restored.State.inventory.Count==all.State.inventory.Count,"save field round trip");
        try {new GameModel(products,new Progress{rubles=-1});throw new Exception("negative save accepted");}catch(ArgumentException){checks++;}
        Check(products.Where(p=>p.kind=="gpu").All(p=>p.price>0&&p.microRate>0&&p.fans>=1&&p.fans<=3),"all authored SKU values");
        Check(products.Where(p=>p.kind=="gpu").OrderByDescending(p=>p.microRate).First().id=="rtx-blackview-5090","BlackView strongest");
        Console.WriteLine("PASS: "+checks+" domain assertions, including purchase/unbox/install for all 113 GPUs.");
    }
}
