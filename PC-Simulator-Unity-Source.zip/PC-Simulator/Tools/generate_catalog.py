"""Deterministic authored game catalogue; prices/rates are fictional, not hardware benchmarks."""
import json
from pathlib import Path
# name|rubles|micro-crypto per second|VRAM GB|board W|fans. Generic housings.
DATA = '''GTX 460|1500|200|1|160|1
GTX 470|1800|250|1.25|215|1
GTX 480|2200|300|1.5|250|1
GTX 550 Ti|1600|210|1|116|1
GTX 560|2000|280|1|150|2
GTX 560 Ti|2400|350|1|170|2
GTX 570|2700|420|1.25|219|1
GTX 580|3200|500|1.5|244|1
GTX 590|4200|700|3|365|1
GTX 650|1700|220|1|64|1
GTX 650 Ti|2100|290|1|110|1
GTX 660|2600|400|2|140|2
GTX 660 Ti|3100|480|2|150|2
GTX 670|3500|580|2|170|2
GTX 680|3900|650|2|195|2
GTX 690|5000|900|4|300|1
GTX 750|2500|450|1|55|1
GTX 750 Ti|3000|600|2|60|2
GTX 760|3400|620|2|170|2
GTX 770|4000|750|2|230|2
GTX 780|4800|900|3|250|1
GTX 780 Ti|5500|1100|3|250|1
GTX 950|3600|700|2|90|2
GTX 960|4300|900|2|120|2
GTX 970|6000|1500|4|145|2
GTX 980|7500|2200|4|165|2
GTX 980 Ti|10000|3800|6|250|3
GTX 1050|4500|850|2|75|1
GTX 1050 Ti|5500|1200|4|75|2
GTX 1060 3GB|6000|1600|3|120|2
GTX 1060 6GB|7000|2000|6|120|2
GTX 1070|10500|3600|8|150|2
GTX 1070 Ti|12500|4500|8|180|2
GTX 1080|14500|5600|8|180|3
GTX 1080 Ti|18000|8000|11|250|3
GTX 1630|4800|950|4|75|1
GTX 1650|6200|1400|4|75|2
GTX 1650 Super|7800|2400|4|100|2
GTX 1660|9000|3000|6|120|2
GTX 1660 Super|11000|4000|6|125|2
GTX 1660 Ti|12000|4400|6|120|2
RTX 2060|17000|7000|6|160|2
RTX 2060 Super|19500|9000|8|175|2
RTX 2070|22000|10000|8|175|2
RTX 2070 Super|25500|12500|8|215|3
RTX 2080|29000|15000|8|215|3
RTX 2080 Super|33000|18000|8|250|3
RTX 2080 Ti|39000|25000|11|250|3
RTX 3050|15500|5500|8|130|2
RTX 3060 8GB|24500|10500|8|170|2
RTX 3060 12GB|27000|12000|12|170|2
RTX 3060 Ti|31000|17000|8|200|2
RTX 3070|35000|22000|8|220|3
RTX 3070 Ti|39500|28000|8|290|3
RTX 3080 10GB|46000|38000|10|320|3
RTX 3080 12GB|49000|42000|12|350|3
RTX 3080 Ti|56000|54000|12|350|3
RTX 3090|65000|70000|24|350|3
RTX 3090 Ti|74000|72000|24|450|3
RTX 4060|28500|14500|8|115|2
RTX 4060 Ti 8GB|36000|21000|8|160|2
RTX 4060 Ti 16GB|40500|23500|16|165|2
RTX 4070|47000|32000|12|200|3
RTX 4070 Super|53000|39000|12|220|3
RTX 4070 Ti|62000|49000|12|285|3
RTX 4070 Ti Super|71000|58000|16|285|3
RTX 4080|90000|69000|16|320|3
RTX 4080 Super|99000|73500|16|320|3
RTX 4090|155000|85000|24|450|3
RTX 5050|30000|16000|8|130|2
RTX 5060|37000|24000|8|145|2
RTX 5060 Ti|49000|36000|16|180|2
RTX 5070|65000|55000|12|250|3
RTX 5070 Ti|85000|68000|16|300|3
RTX 5080|130000|90000|16|360|3
RTX 5090|230000|95000|32|575|3
RTX BlackView 5090|350000|100000|32|600|3
RX 460|1700|230|2|75|1
RX 470|2800|520|4|120|2
RX 480|3800|800|8|150|2
RX 550|1600|205|2|50|1
RX 560|2300|380|4|80|1
RX 570|3500|750|4|150|2
RX 580 4GB|4500|920|4|185|2
RX 580 8GB|5000|1000|8|185|2
RX 590|6200|1450|8|225|2
RX Vega 56|9500|3300|8|210|1
RX Vega 64|12500|4600|8|295|1
RX 5500 XT|8500|2700|8|130|2
RX 5600 XT|13000|4800|6|150|2
RX 5700|16000|6500|8|180|2
RX 5700 XT|20000|9500|8|225|3
RX 6400|9500|3100|4|53|1
RX 6500 XT|11500|4100|4|107|2
RX 6600|18500|10000|8|132|2
RX 6600 XT|23000|14000|8|160|2
RX 6650 XT|25500|16500|8|176|2
RX 6700 XT|29500|20000|12|230|3
RX 6750 XT|32500|24000|12|250|3
RX 6800|38500|31000|16|250|3
RX 6800 XT|45000|40000|16|300|3
RX 6900 XT|55000|52000|16|300|3
RX 6950 XT|63000|61000|16|335|3
RX 7600|26000|15500|8|165|2
RX 7600 XT|33000|22500|16|190|2
RX 7700 XT|41000|34000|12|245|3
RX 7800 XT|49000|45000|16|263|3
RX 7900 GRE|59000|56000|16|260|3
RX 7900 XT|79000|67000|20|315|3
RX 7900 XTX|100000|75000|24|355|3
RX 9060 XT|38000|30000|16|160|2
RX 9070|68000|63000|16|220|3
RX 9070 XT|89000|76000|16|304|3'''

def generate():
    items=[]
    for line in DATA.splitlines():
        name, price, rate, vram, watts, fans = line.split('|')
        num=name.split()[1]
        series=('Vega' if num=='Vega' else 'BlackView' if num=='BlackView' else num[0]+'000' if len(num)==4 else num[0]+'00')
        if num.startswith('16'): series='1600'
        items.append(dict(id=name.lower().replace(' ','-'),name=name,kind='gpu',brand='AMD' if name.startswith('RX') else 'NVIDIA',series=series,price=int(price),microRate=int(rate),vram=float(vram),watts=int(watts),fans=int(fans),score=int(rate),socket='',memory=''))
    def part(id,name,kind,price,watts=0,socket='',memory='',score=0):
        items.append(dict(id=id,name=name,kind=kind,brand='PC Sim',series=kind,price=price,microRate=0,vram=0,watts=watts,fans=0,score=score,socket=socket,memory=memory))
    for row in [('cpu-basic','Core i3 Starter','cpu',2000,54,'LGA1150','',2),('cpu-mid','Ryzen 5 Builder','cpu',10000,65,'AM4','',6),('cpu-pro','Ryzen 9 Creator','cpu',45000,170,'AM5','',16),('board-basic','Basic H81','board',1800,0,'LGA1150','DDR3'),('board-mid','Builder B550','board',7000,0,'AM4','DDR4'),('board-pro','Creator X870','board',28000,0,'AM5','DDR5')]: part(*row)
    for mem,sizes in [('DDR3',[0.25,1,2,4,8,16]),('DDR4',[4,8,16,32,64]),('DDR5',[8,16,32,64,128])]:
        for gb in sizes: part(f'ram-{mem}-{gb}',f'{mem} {int(gb*1024) if gb<1 else gb} '+('MB' if gb<1 else 'GB'),'ram',int(300+gb*(80 if mem=='DDR3' else 140 if mem=='DDR4' else 220)),memory=mem,score=int(gb*1024))
    part('cooler-basic','Air 90','cooler',500,score=90)
    part('cooler-pro','Tower 240','cooler',3500,score=240)
    part('case-basic','Office ATX','case',1500)
    part('case-pro','Panorama ATX','case',8500)
    for watts,price in [(500,1800),(750,4500),(1000,9000),(1600,18000)]: part(f'psu-{watts}',f'Power {watts} W','psu',price,score=watts)
    assert len([x for x in items if x['kind']=='gpu'])==113
    out=Path(__file__).resolve().parents[1]/'Assets/Resources/catalog.json'
    out.write_text(json.dumps({'items':items},ensure_ascii=False,indent=2)+'\n')
    print(f'{len(items)} products; 113 GPUs -> {out}')
if __name__=='__main__': generate()
