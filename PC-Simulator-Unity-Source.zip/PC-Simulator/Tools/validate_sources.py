"""Source checks. Requires: pip install tree-sitter tree-sitter-c-sharp."""
import json,re,sys
from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
root=Path(__file__).resolve().parents[1]
parser=Parser(Language(tree_sitter_c_sharp.language()))
errors=[]
for path in (root/'Assets').rglob('*.cs'):
    tree=parser.parse(path.read_bytes())
    def walk(n):
        if n.type=='ERROR' or n.is_missing: errors.append(f'{path.relative_to(root)}:{n.start_point[0]+1}: {n.type}')
        for c in n.children:walk(c)
    walk(tree.root_node)
assets=list((root/'Assets').rglob('*'))
for p in assets:
    if p.suffix!='.meta' and not Path(str(p)+'.meta').exists():errors.append('Missing meta: '+str(p))
guids=[re.search(r'^guid: (\w+)',p.read_text(),re.M).group(1) for p in assets if p.suffix=='.meta']
assert len(guids)==len(set(guids)),'Duplicate GUIDs'
for p in root.rglob('*.json'):
    if '.git' not in p.parts and 'obj' not in p.parts and 'bin' not in p.parts: json.loads(p.read_text())
assert '4967276cb23d441e9163a36ed774a120' in (root/'ProjectSettings/EditorBuildSettings.asset').read_text()
assert 'rubles=30000' in (root/'Assets/Scripts/GameModel.cs').read_text()
assert len(json.loads((root/'Assets/Resources/videos.json').read_text())['videos'])==7
if errors: print('\n'.join(errors));sys.exit(1)
print(f'PASS: {len(list((root/"Assets").rglob("*.cs")))} C# syntax trees; JSON, metadata GUIDs, scene reference and 7 GoTube entries.')
