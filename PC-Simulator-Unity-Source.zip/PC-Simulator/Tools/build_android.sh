#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
editor="${UNITY_EDITOR:-}"
if [[ -z "$editor" || ! -x "$editor" ]]; then
  echo 'APK build blocked: set UNITY_EDITOR to a licensed Unity 2022.3.62f1 executable with Android Build Support, SDK/NDK and OpenJDK.' >&2
  exit 2
fi
"$editor" -batchmode -nographics -quit -buildTarget Android -projectPath "$PWD" -executeMethod PCSim.Editor.BuildAndroid.Build -logFile -
test -s Builds/Android/PC-Simulator.apk
