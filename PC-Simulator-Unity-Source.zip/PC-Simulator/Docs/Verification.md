# Verification — 2026-11-21

## Executed successfully

- .NET SDK 8.0.408 compiles the actual `Assets/Scripts/GameModel.cs` linked into DomainChecks.
- **501 domain assertions pass.** Coverage: 113 distinct GPU IDs, 30 other products, 30000 starting rubles and no free parts, purchase/delivery deadlines/unboxing/installing, no overdraft, compatibility on CPU/RAM/board replacement, 65% resale, complete first build within the budget, cooler capacity, PSU capacity, no income from an incomplete PC, exact 3090 and BlackView mining rates, fractional mining accounting, fictional exchange and JSON field round trip using System.Text.Json.
- .NET compiles the actual `Assets/Scripts/LanSession.cs` with minimal test-only Unity adapters. **68 assertions pass** against real loopback TCP sockets: host + 3 clients, unique slots, host poses, guest pose forwarding, fifth-player rejection, disconnect propagation, malformed/oversized packet handling, host shutdown. The assertion count includes repeated received host-pose checks.
- Tree-sitter parses all **7 Unity C# source files** without syntax errors; metadata GUID uniqueness, metadata presence, JSON syntax, build-scene GUID and 7 video entries pass.
- `Tools/build_android.sh` was executed and exited **2** with an explicit missing-Unity preflight error. No APK was produced.

## Not verified

Unity compilation/import, Play Mode, scene/material/font rendering, generated packaging artwork, actual video playback, IMGUI Android touch behavior, IL2CPP, Android manifest merge, SDK/NDK integration, APK installation, mobile performance and real Wi-Fi on separate devices. Passing .NET checks is not a substitute for these checks. The LAN adapters use System.Text.Json in place of Unity JsonUtility; the actual Unity serializer still needs device testing.

## Known implementation limits

- Procedural placeholder apartment/city/avatars and universal GPU housings; not photorealistic or exact licensed partner-board replicas. Housing/fan parameters are game configurations.
- Starter monitor is labelled 640×480; no separate low-resolution desktop renderer.
- Assembly uses inventory buttons with compatibility checks and visual slots, not drag-and-drop assembly, cable routing or screws.
- Film peeling has a generated sound and timed step; no deforming protective-film mesh.
- Seven GoTube YouTube links open externally. Empty `directUrl` fields mean the popular videos are not embedded or bundled. VideoPlayer supports a configured direct MP4.
- Multiplayer synchronizes avatars and allocates independent desks. It does not synchronize purchase inventories, installed PC parts, video state or a shared economy.
- Active-session mining only. No offline mining. Save files are local, unencrypted, schema version 1; no cloud sync.
- GPU and part prices, mining rates, performance score and crypto exchange are game balance values, not real prices, profitability or benchmarks.

## Required next checks in Unity

1. Import in 2022.3.62f1 with Android Build Support; resolve any import/compiler diagnostics.
2. Play Apartment scene; confirm Cyrillic labels, screen UI, movement and collision.
3. Complete the first build from 30000 rubles; inspect/rotate/open each product kind, install/remove/sell; reopen the game to check Unity JSON persistence.
4. Build ARM64 APK using the supplied build menu/script, install on Android, check landscape/safe-area layout and simultaneous movement/look touches.
5. Connect at least two separate Android devices on one Wi-Fi, verify IPv4 display, guests and disconnect/reconnect.
6. Supply a permitted HTTPS direct MP4 and test TV picture/audio/error handling. Verify external YouTube links on the device.

## Git delivery

Local stage commits are available. GitHub Git Trees write returned HTTP 403 `Resource not accessible by integration`; authenticated `git push` could not find credentials. The fallback cloud browser is signed out of GitHub. No source changes have been uploaded to the remote repository during this run. Reconnect GitHub with contents write permission for `houb0ard777-web/PC-Simulator` before uploading these commits.
